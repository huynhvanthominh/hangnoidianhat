<?php
define("SALT", "hangnoidianhat");
define("ADMIN", "admin");
define("CUSTOMERS", "customers");
define("NAMEWEBSITE", "hangnoidianhat");
define("HOME_SCRIPT", "<script>location.assign('home')</script>");