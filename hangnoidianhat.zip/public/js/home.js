$(document).ready(function(){
    setTitle("Trang chủ")
})