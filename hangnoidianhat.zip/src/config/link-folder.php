<?php
define("VIEWS", "./src/mvc/views/");
define("CONTROLLERS", "./src/mvc/controllers/");
define("MODELS", "./src/mvc/models/");