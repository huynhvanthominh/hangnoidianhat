<?php
define("ROLE", [
    "CUSTOMERS" => 0,
    "ADMIN" => 1,
    "MANAGER" => 2
]);